# 1.0.0
Initial Acid VOG: monophonic acid voice, slide/accent/vibrato, 16-slot step sequencer, 128 factory scenes, effects, patch save/load, MIDI export, silver interface and Windows build workflow.
