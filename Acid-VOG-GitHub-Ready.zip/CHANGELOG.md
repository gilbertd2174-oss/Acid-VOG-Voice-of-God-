# 1.0.3
Add 128 new patches for 256 total. New banks: Deep Sub, Pluck, Metallic, Space, Echo Motion, Minimal, Slow Burn and Peak Time. Existing patch numbers and sound settings remain unchanged.

# 1.0.2
Darker grey panel background; pure black numeric readouts, editable numeric text and sequencer numbers; light number boxes and sequencer headings preserve contrast.

# 1.0.1
Fix MSVC C2666 in the step-flag drawing call. Both sequencer cell drawing calls now use explicit Rectangle<float> arguments to avoid mixed int/float overload selection.

# 1.0.0
Initial Acid VOG: monophonic acid voice, slide/accent/vibrato, 16-slot step sequencer, 128 factory scenes, effects, patch save/load, MIDI export, silver interface and Windows build workflow.
