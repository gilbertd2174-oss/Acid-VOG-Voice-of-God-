#pragma once
#include "SynthEngine.h"
#include "AcidParameters.h"
namespace acid {
struct ClockPosition{int step=0;int64_t serial=0;double fraction=0;};
inline ClockPosition clockAt(double ppq,int length,int rate,float swing){const double beats[]={.5,.25,1.0/6,.125};double u=ppq/beats[(size_t)rate];double pair=std::floor(u/2);double within=u-pair*2;double split=1+std::max(0.f,swing)*.01;int odd=within>=split?1:0;int64_t serial=(int64_t)pair*2+odd;double fraction=odd?(within-split)/(2-split):within/split;int step=(int)((serial%length+length)%length);return {step,serial,fraction};}
class Engine{
 float sr=48000,phase=0,subPhase=0,vibPhase=0,pitch=36,targetPitch=36,amp=0,env=0,accentEnv=0,bend=0,wheel=0;
 bool held=false,sliding=false,vibrato=false;Values current=defaults(),target=defaults();davoe::Filter filter1,filter2;davoe::Effects fx;davoe::Values fxValues=davoe::defaults();float slew=.001f;
public:
 void prepare(double rate){sr=(float)rate;slew=1-std::exp(-1.f/(sr*.012f));fx.prepare(sr);reset();setParameters(target);current=target;}
 void setParameters(const Values&p){for(size_t i=0;i<p.size();i++)target[i]=std::isfinite(p[i])?davoe::clamp(p[i],specs[i].lo,specs[i].hi):specs[i].initial;
  fxValues[davoe::CompOn]=0;fxValues[davoe::EqOn]=0;fxValues[davoe::DistOn]=1;fxValues[davoe::DistMode]=target[DistType];fxValues[davoe::DistDrive]=target[DistAmount];fxValues[davoe::DistTreble]=target[DistColor];fxValues[davoe::DistBass]=-target[DistColor]*.4f;fxValues[davoe::DistMix]=target[DistMix];fxValues[davoe::DistLevel]=-3;
  fxValues[davoe::Chorus]=target[Chorus];fxValues[davoe::DelayMix]=target[EchoMix];fxValues[davoe::DelayTime]=target[EchoTime];fxValues[davoe::Feedback]=target[EchoFeedback];fxValues[davoe::EchoSync]=target[EchoSync];fxValues[davoe::EchoHeads]=1;fxValues[davoe::Reverb]=target[ReverbMix];fxValues[davoe::Space]=target[Room];fxValues[davoe::VerbDecay]=1+target[Room]*6;fxValues[davoe::PreDelay]=target[PreDelay];fx.update(fxValues,sr);
 }
 void note(int n,float velocity,bool accent,bool slide,bool vib){targetPitch=(float)n;vibrato=vib;sliding=slide&&amp>.001f;if(!sliding){pitch=targetPitch;env=davoe::clamp(velocity,.1f,1);accentEnv=accent?1.f:0.f;}else if(accent)accentEnv=1;held=true;}
 void off(){held=false;}
 void pitchWheel(float semitones){bend=semitones;}void modWheel(float value){wheel=value;}
 void reset(){phase=subPhase=vibPhase=amp=env=accentEnv=bend=wheel=0;held=sliding=vibrato=false;filter1.reset();filter2.reset();fx.reset();}
 void sample(float& l,float&r,double bpm){for(size_t i=0;i<current.size();i++)current[i]+=(target[i]-current[i])*slew;
  if(sliding)pitch+=(targetPitch-pitch)*(1-std::exp(-1.f/(sr*.001f*current[Slide])));else pitch=targetPitch;
  vibPhase+=current[VibratoRate]/sr;if(vibPhase>=1)vibPhase-=1;
  float hz=davoe::midiHz(pitch+bend+current[Tune]*.01f+std::sin(2*davoe::pi*vibPhase)*current[VibratoDepth]*.01f*(vibrato?1.f:wheel));float dt=std::min(.45f,hz/sr);
  float x=davoe::oscillator(phase,dt,(int)target[Wave],.5f)+std::sin(2*davoe::pi*subPhase)*current[Sub];phase+=dt;phase-=std::floor(phase);subPhase+=dt*.5f;subPhase-=std::floor(subPhase);
  env*=std::exp(-1/(sr*current[Decay]*.001f));accentEnv*=std::exp(-1/(sr*current[AccentDecay]*.001f));
  float cutoff=current[Cutoff]*std::exp2(env*current[EnvDepth]+accentEnv*current[Accent]*1.4f);
  x=std::tanh(x*(1+current[Drive]*4))*.7f;x=filter1.tick(x,cutoff,current[Resonance],0,sr);x=filter2.tick(x,cutoff,0,0,sr);
  amp+=((held?1.f:0.f)-amp)*(1-std::exp(-1.f/(sr*(held?.002f:.009f))));x*=amp*(.7f+accentEnv*current[Accent]*.7f)*.5f;
  l=r=x;fx.tick(l,r,fxValues,sr,bpm,wheel);float gain=std::pow(10.f,current[Volume]/20.f);l=std::tanh(l*gain);r=std::tanh(r*gain);if(!std::isfinite(l)||!std::isfinite(r)){reset();l=r=0;}
 }
};
}
