# Validation status

Local checks: complete workflow parsed; inline PowerShell syntax checked; actual source ZIP extracted and project found by the workflow scripts; parameter/spec counts, UI parameter coverage, preset count and source structure checked; source archive integrity checked. Interface preview was rendered from the control layout and visually inspected.

This environment has no C++ compiler or CMake. Acid VOG has NOT been compiled here; its new engine tests have NOT been executed here. The preview is an illustrative render, not a screenshot of a running plugin. Listening, MIDI export interoperability, session restore, DAW transport and plugin-validator checks remain to be performed after a successful Windows build.

The included C++ tests check step packing, swing/clock boundaries, scene ranges and uniqueness, finite audio, note/slide/reset behavior and 44.1/48/96 kHz operation. GitHub runs these before packaging.

Manual checks: preview all 128 scenes; test every pattern flag and gate length; start/stop/loop/jump DAW transport; try internal clock and MIDI keyboard modes; save/load edited banks; export/reimport MIDI; test automation, UI scaling and CPU at the buffer size you use. The voice is an original analog-style model and makes no circuit-authenticity claim.
